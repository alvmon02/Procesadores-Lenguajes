package asint;

import asint.SintaxisAbstractaTiny.*;

public class ProcesamientoDef implements Procesamiento {
    public void procesa(Prog prog) {
    }

    public void procesa2(Prog prog) {
    }

    public void procesa(Bloque bloque) {
    }

    public void procesa2(Bloque bloque) {
    }

    public void procesa(Si_Decs decs) {
    }

    public void procesa2(Si_Decs decs) {
    }

    public void procesa(No_Decs decs) {
    }

    public void procesa2(No_Decs decs) {
    }

    public void procesa(Mas_Decs decs) {
    }

    public void procesa2(Mas_Decs decs) {
    }

    public void procesa(Una_Dec dec) {
    }

    public void procesa2(Una_Dec dec) {
    }

    public void procesa(Dec_Var dec_Var) {
    }

    public void procesa2(Dec_Var dec_Var) {
    }

    public void procesa(Dec_Tipo dec_Tipo) {
    }

    public void procesa2(Dec_Tipo dec_Tipo) {
    }

    public void procesa(Dec_Proc dec_Proc) {
    }

    public void procesa2(Dec_Proc dec_Proc) {
    }

    public void procesa(Si_PForms si_PForms) {
    }

    public void procesa2(Si_PForms si_PForms) {
    }

    public void procesa(No_PForms no_PForms) {
    }

    public void procesa2(No_PForms no_PForms) {
    }

    public void procesa(Mas_PForms mas_PForms) {
    }

    public void procesa2(Mas_PForms mas_PForms) {
    }

    public void procesa(Una_PForm una_PForm) {
    }

    public void procesa2(Una_PForm una_PForm) {
    }

    public void procesa(PForm pform) {
    }

    public void procesa2(PForm pform) {
    }

    public void procesa(Si_Ref si_Ref) {
    }

    public void procesa2(Si_Ref si_Ref) {
    }

    public void procesa(No_Ref no_Ref) {
    }

    public void procesa2(No_Ref no_Ref) {
    }

    public void procesa(T_Iden tIden) {
    }

    public void procesa2(T_Iden tIden) {
    }

    public void procesa(T_String tstring) {
    }

    public void procesa2(T_String tstring) {
    }

    public void procesa(T_Int tint) {
    }

    public void procesa2(T_Int tint) {
    }

    public void procesa(T_Bool tbool) {
    }

    public void procesa2(T_Bool tbool) {
    }

    public void procesa(T_Real treal) {
    }

    public void procesa2(T_Real treal) {
    }

    public void procesa(T_Array tArray) {
    }

    public void procesa2(T_Array tArray) {
    }

    public void procesa(T_Puntero tPuntero) {
    }

    public void procesa2(T_Puntero tPuntero) {
    }

    public void procesa(T_Struct tStruct) {
    }

    public void procesa2(T_Struct tStruct) {
    }

    public void procesa(Mas_Cmp_S mas_Cmp_S) {
    }

    public void procesa2(Mas_Cmp_S mas_Cmp_S) {
    }

    public void procesa(Un_Cmp_S un_Cmp_S) {
    }

    public void procesa2(Un_Cmp_S un_Cmp_S) {
    }

    public void procesa(CampoS campoS) {
    }

    public void procesa2(CampoS campoS) {
    }

    public void procesa(Si_Intrs si_Intrs) {
    }

    public void procesa2(Si_Intrs si_Intrs) {
    }

    public void procesa(No_Intrs no_Intrs) {
    }

    public void procesa2(No_Intrs no_Intrs) {
    }

    public void procesa(Mas_Intrs mas_Intrs) {
    }

    public void procesa2(Mas_Intrs mas_Intrs) {
    }

    public void procesa(Una_Intr una_Intr) {
    }

    public void procesa2(Una_Intr una_Intr) {
    }

    public void procesa(I_Eval i_Eval) {
    }

    public void procesa2(I_Eval i_Eval) {
    }

    public void procesa(I_If i_If) {
    }

    public void procesa2(I_If i_If) {
    }

    public void procesa(I_While i_While) {
    }

    public void procesa2(I_While i_While) {
    }

    public void procesa(I_Read i_Read) {
    }

    public void procesa2(I_Read i_Read) {
    }

    public void procesa(I_Write i_Write) {
    }

    public void procesa2(I_Write i_Write) {
    }

    public void procesa(I_NL i_Nl) {
    }

    public void procesa2(I_NL i_Nl) {
    }

    public void procesa(I_New i_New) {
    }

    public void procesa2(I_New i_New) {
    }

    public void procesa(I_Delete i_Delete) {
    }

    public void procesa2(I_Delete i_Delete) {
    }

    public void procesa(I_Call i_Call) {
    }

    public void procesa2(I_Call i_Call) {
    }

    public void procesa(I_Prog i_Prog) {
    }

    public void procesa2(I_Prog i_Prog) {
    }

    public void procesa(Si_Else si_Else) {
    }

    public void procesa2(Si_Else si_Else) {
    }

    public void procesa(No_Else no_Else) {
    }

    public void procesa2(No_Else no_Else) {
    }

    public void procesa(Si_PReals si_PReals) {
    }

    public void procesa2(Si_PReals si_PReals) {
    }

    public void procesa(No_PReals no_PReals) {
    }

    public void procesa2(No_PReals no_PReals) {
    }

    public void procesa(Mas_PReals mas_PReals) {
    }

    public void procesa2(Mas_PReals mas_PReals) {
    }

    public void procesa(Un_PReal un_PReal) {
    }

    public void procesa2(Un_PReal un_PReal) {
    }

    public void procesa(Asig exp) {
    }

    public void procesa2(Asig exp) {
    }

    public void procesa(Comp exp) {
    }

    public void procesa2(Comp exp) {
    }

    public void procesa(Dist exp) {
    }

    public void procesa2(Dist exp) {
    }

    public void procesa(Menor exp) {
    }

    public void procesa2(Menor exp) {
    }

    public void procesa(Mayor exp) {
    }

    public void procesa2(Mayor exp) {
    }

    public void procesa(MenorIgual exp) {
    }

    public void procesa2(MenorIgual exp) {
    }

    public void procesa(MayorIgual exp) {
    }

    public void procesa2(MayorIgual exp) {
    }

    public void procesa(Suma exp) {
    }

    public void procesa2(Suma exp) {
    }

    public void procesa(Resta exp) {
    }

    public void procesa2(Resta exp) {
    }

    public void procesa(And exp) {
    }

    public void procesa2(And exp) {
    }

    public void procesa(Or exp) {
    }

    public void procesa2(Or exp) {
    }

    public void procesa(Mul exp) {
    }

    public void procesa2(Mul exp) {
    }

    public void procesa(Div exp) {
    }

    public void procesa2(Div exp) {
    }

    public void procesa(Porcentaje exp) {
    }

    public void procesa2(Porcentaje exp) {
    }

    public void procesa(Negativo exp) {
    }

    public void procesa2(Negativo exp) {
    }

    public void procesa(Negado exp) {
    }

    public void procesa2(Negado exp) {
    }

    public void procesa(Index exp) {
    }

    public void procesa2(Index exp) {
    }

    public void procesa(Acceso exp) {
    }

    public void procesa2(Acceso exp) {
    }

    public void procesa(Indireccion exp) {
    }

    public void procesa2(Indireccion exp) {
    }

    public void procesa(Lit_ent exp) {
    }

    public void procesa2(Lit_ent exp) {
    }

    public void procesa(True exp) {
    }

    public void procesa2(True exp) {
    }

    public void procesa(False exp) {
    }

    public void procesa2(False exp) {
    }

    public void procesa(Lit_real exp) {
    }

    public void procesa2(Lit_real exp) {
    }

    public void procesa(Cadena exp) {
    }

    public void procesa2(Cadena exp) {
    }

    public void procesa(Iden exp) {
    }

    public void procesa2(Iden exp) {
    }

    public void procesa(Null exp) {
    }

    public void procesa2(Null exp) {
    }

    public void procesa(Exp exp) {
    }

    public void procesa2(Exp exp) {
    }

    @SuppressWarnings("rawtypes")
    public static boolean claseDe(Object o, Class c) {
        return o.getClass() == c;
    }

    public static Tipo referenciar(Tipo tipo) {
        if (claseDe(tipo, T_Iden.class))
            return referenciar(tipo.vinculo().tipo());
        else
            return tipo;
    }
}
