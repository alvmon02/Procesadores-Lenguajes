package ebin;

public enum ClaseLexica {BIT,EOF}
