package ebin;

import java.io.IOException;
import java.io.Reader;
import java.util.EnumSet;
import java.util.Set;

public class EvaluadorBin {
   private UnidadLexica anticipo;       // token adelantado
   private AnalizadorLexicoBin alex;   // analizador l�xico 
   private GestionErroresBin errores;  // gestor de errores
   private Set<ClaseLexica> esperados;  // clases l�xicas esperadas
   private SemOps sem;  // Funciones sem�nticas
   
   public EvaluadorBin(Reader input) throws IOException {
        // se crea el gestor de errores
      errores = new GestionErroresBin();
        // se crea el analizador l�xico
      alex = new AnalizadorLexicoBin(input,errores);
      esperados = EnumSet.noneOf(ClaseLexica.class);
      sem = new SemOps();
        // Se lee el primer token adelantado
      sigToken();                      
   }
   public int evalua() {
      int bits_val = bits();
      empareja(ClaseLexica.EOF);
      return bits_val;
   }
   private int bits() {   
       String BIT_lex = empareja(ClaseLexica.BIT);
       int rbits_valor = rbits(sem.valorDe(BIT_lex));
       return rbits_valor;
   }
   
   private int rbits(int rbits0_valorh) {
       switch(anticipo.clase()) {
           case BIT: 
                 String BIT_lex = empareja(ClaseLexica.BIT);
                 int rbits1_valor = rbits(rbits0_valorh*2 + sem.valorDe(BIT_lex));
                 return rbits1_valor;
           default:        
                return rbits0_valorh;
       } 
   }
   
   private void esperados(ClaseLexica ... esperadas) {
       for(ClaseLexica c: esperadas) {
           esperados.add(c);
       }
   }
   
   
   private String empareja(ClaseLexica claseEsperada) {
      if (anticipo.clase() == claseEsperada) {
          String lexema = anticipo.lexema();
          sigToken();
          return lexema;
      }    
      else {
          esperados(claseEsperada);
          error();
          return "";
      }
   }
   private void sigToken() {
      try {
        anticipo = alex.sigToken();
        esperados.clear();
      }
      catch(IOException e) {
        errores.errorFatal(e);
      }
   }
   
    private void error() {
        errores.errorSintactico(anticipo.fila(), anticipo.columna(), anticipo.clase(), esperados);
    }
    
}
