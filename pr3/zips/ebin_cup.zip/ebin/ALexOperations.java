package ebin;

import ebin.ClaseLexica;

public class ALexOperations {
    
  private AnalizadorLexicoBin alex;
  public ALexOperations(AnalizadorLexicoBin alex) {
   this.alex = alex;   
  }
  public UnidadLexica unidadBit() {
     return new UnidadLexica(alex.fila(), alex.columna(),ClaseLexica.BIT,alex.lexema()); 
  } 
  public UnidadLexica unidadEof() {
     return new UnidadLexica(alex.fila(), alex.columna(),ClaseLexica.EOF,"<EOF>"); 
  }

}
