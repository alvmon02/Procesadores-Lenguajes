import ebin.AnalizadorLexicoBin;
import ebin.EvaluadorBin;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class Main {
   public static void main(String[] args) throws Exception {
     Reader input = new InputStreamReader(new FileInputStream(args[0]));
	 AnalizadorLexicoBin alex = new AnalizadorLexicoBin(input);
	 EvaluadorBin asint = new EvaluadorBin(alex);
	 System.out.println(asint.parse().value);
 }
}   
   
